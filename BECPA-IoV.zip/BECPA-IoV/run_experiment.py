from src.experiment import run_experiments
if __name__ == "__main__":
    run_experiments()
